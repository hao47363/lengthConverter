import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  input_length: string = '0';
  input_length2: string = '0';
  prev_length: string = '0';
  option: string;
  unit: string[] = ['m', 'cm', 'mm', 'ft', 'inch'];
  current_unit1 = this.unit[1];
  current_unit2 = this.unit[0];
  result: number = 0;
  isNewNum: boolean = true;
  isDecimal: boolean = false;
  temp1: number = 0;
  temp2: number = 0;
  total: number = 0;
  operator: string;
  ans: number = 0;

  constructor() { };

  @HostListener('keyup') lengthStandardize() {
    switch (this.current_unit1) {
      case 'm':
        this.calculateTotal();
        document.getElementById("inputLength").innerHTML = this.total.toString();
        this.lengthConverter(this.total * 100.0);
        break;

      case 'cm':
        this.calculateTotal();
        document.getElementById("inputLength").innerHTML = this.total.toString();
        this.lengthConverter(this.total);
        break;

      case 'mm':
        this.calculateTotal();
        document.getElementById("inputLength").innerHTML = this.total.toString();
        this.lengthConverter(this.total / 10.0);
        break;

      case 'ft':
        this.calculateTotal();
        document.getElementById("inputLength").innerHTML = this.total.toString();
        this.lengthConverter(this.total / 0.032808399);
        break;

      case 'inch':
        this.calculateTotal();
        document.getElementById("inputLength").innerHTML = this.total.toString();
        this.lengthConverter(this.total / 0.393700787);
        break;
    }
  }

  lengthStandardize2(val) {
    switch (this.current_unit1) {
      case 'm':
        this.input_length = (parseFloat(val) * 100).toString();
        break;

      case 'cm':
        this.input_length = this.input_length;
        break;

      case 'mm':
        this.input_length = (parseFloat(val) / 10.0).toString();
        break;

      case 'ft':
        this.input_length = (parseFloat(val) / 0.032808399).toString();
        break;

      case 'inch':
        this.input_length = (parseFloat(val) / 0.393700787).toString();
        break;
    }
  }

  lengthConverter(val) {
    switch (this.current_unit2) {
      case 'm':
        this.result = val / 100;
        this.ans = this.result;
        document.getElementById("outputLength").innerHTML = (this.result.toFixed(8)).toString();
        break;

      case 'cm':
        this.result = val;
        this.ans = this.result;
        document.getElementById("outputLength").innerHTML = (this.result.toFixed(8)).toString();
        break;

      case 'mm':
        this.result = val * 10.0;
        this.ans = this.result;
        document.getElementById("outputLength").innerHTML = (this.result.toFixed(8)).toString();
        break;

      case 'ft':
        this.result = val * 0.032808399;
        this.ans = this.result;
        document.getElementById("outputLength").innerHTML = (this.result.toFixed(8)).toString();
        break;

      case 'inch':
        this.result = val * 0.393700787;
        this.ans = this.result;
        document.getElementById("outputLength").innerHTML = (this.result.toFixed(8)).toString();
        break;
    }

  }

  btnClickAC() {
    this.input_length = '0';
    this.input_length2 = '0';
    document.getElementById("inputLength").innerHTML = this.input_length;
    document.getElementById("outputLength").innerHTML = this.input_length;
    this.isNewNum = true;
    this.isDecimal = false;
    this.operator = '';
  }

  btnClickNum(num) {
    if (this.isDecimal == false) {
      if (this.isNewNum) {
        this.input_length = '' + num;
      } else {
        this.input_length += '' + num;
      }
    } else if (this.isDecimal == true) {
      if (this.isNewNum) {
        this.input_length2 = '' + num;
      } else {
        this.input_length2 += '' + num;
      }
    }
    this.isNewNum = false;
    this.lengthStandardize();
  }

  btnClickAns() {
    document.getElementById("outputLength").innerHTML = (this.ans.toFixed(2)).toString();
  }

  btnClickDecimal() {
    if (this.isDecimal === false) {
      this.isDecimal = true;
    } else {
      this.isDecimal = false;
    }
  }

  btnClickOperator(symbol) {
    if (symbol === '=') {
      if (this.operator === '+') {
        this.lengthStandardize2(this.input_length);
        this.input_length = '' + (parseFloat(this.prev_length) + parseFloat(this.input_length));
        this.current_unit1 = this.unit[1];
        this.lengthStandardize();
      } else if (this.operator === '-') {
        this.lengthStandardize2(this.input_length);
        this.input_length = '' + (parseFloat(this.prev_length) - parseFloat(this.input_length));
        this.current_unit1 = this.unit[1];
        this.lengthStandardize();
      } else if (this.operator === 'x') { //Semantic error
        this.lengthStandardize2(this.input_length);
        this.input_length = '' + (parseFloat(this.prev_length) * parseFloat(this.input_length));
        this.current_unit1 = this.unit[1];
        this.lengthStandardize();
      } else if (this.operator === '/') { //Semantic error
        this.lengthStandardize2(this.input_length);
        this.input_length = '' + (parseFloat(this.prev_length) / parseFloat(this.input_length));
        this.current_unit1 = this.unit[1];
        this.lengthStandardize();
      } else if (this.operator === 'pow') {
        this.input_length = '' + Math.pow(parseFloat(this.prev_length), 2);
        this.lengthStandardize();
      } else if (this.operator === 'sqrt') {
        this.input_length = '' + Math.sqrt(parseFloat(this.prev_length));
        this.lengthStandardize();
      }
    } else {
      this.isNewNum = true;
      this.lengthStandardize2(this.input_length);
      this.prev_length = this.input_length;
      this.operator = symbol;
    }
  }

  calculateTotal() {
    this.temp1 = parseFloat(this.input_length);
    this.temp2 = (parseFloat(this.input_length2) / (Math.pow(10, (this.input_length2.length - 1))));
    this.total = this.temp1 + this.temp2;
  }

  btnClickUnit(unit) {
    this.current_unit1 = this.unit[this.unit.indexOf(unit)];
  }

}
